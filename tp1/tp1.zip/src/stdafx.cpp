#include "stdafx.h"
#ifdef __linux__
int INVALID_SOCKET = -1;
int SOCKET_ERROR = -1;
#endif
